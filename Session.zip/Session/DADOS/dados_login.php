<?php 

    session_start();

    if(isset($_GET['logout']) && $_GET['logout'] == 1) {
        $_SESSION = array();
        session_destroy();
        header('Location: /Session');
    }

    $_SESSION['resumo'] = [];
    $_SESSION['valorTotalResumo'] = [];
    $strResumo = "";
    $floResumo = 0;
    $vBD = [];

    if(isset($_GET['finalizar']) && $_GET['finalizar'] == 1) {

        for($i = 0; $i < $_SESSION['contador']; $i++){
            $_SESSION['resumo'][] = $_SESSION['valores'][$i]["id"] . "[" . $_SESSION['valores'][$i]["qtd"] . "];";
            $_SESSION['valorTotalResumo'][] = $_SESSION['valores'][$i]["vTotal"];
        }

        for($i = 0; $i < $_SESSION['contador']; $i++){
            $strResumo .= $_SESSION['resumo'][$i];
            $floResumo = array_sum($_SESSION['valorTotalResumo']);
        }
        
        require_once('database.php');

        $query = $conn->prepare("INSERT INTO recibo(relacao,valorTotal,idPessoa) VALUES(?, ?, ?)");
        $query->bind_param("sdi", $strResumo, $floResumo, $_SESSION['idUser']);
        $query->execute();

        $valBD = $conn->query("SELECT valor FROM pessoa WHERE id = {$_SESSION['idUser']}");

        while($bdVAL = $valBD->fetch_assoc()){
            foreach($bdVAL as $m){
                $vBD[] = $m;
            }
        }

        $vBDADD = $vBD[0] + 1;

        $q = $conn->prepare("UPDATE pessoa SET valor = {$vBDADD} WHERE id = {$_SESSION['idUser']}");
        $q->execute();

        $_SESSION['valores'] = array();
        $_SESSION['contador'] = array();

        echo "<script>alert('Recibo faturado!')</script>";

    }

    $_SESSION['logged'] = $_SESSION['logged'] ?? False;
    
    if(isset($_REQUEST['user']) && isset($_REQUEST['pass'])){

        $p_user = $_POST['user'] ?? NULL;
        $p_senha = $_POST['pass'] ?? NULL;
        $rel = [];

        require_once('database.php');

        $sql = $conn->query("SELECT id,nome,senha,cargo FROM pessoa WHERE nome = '{$p_user}'");

        while($row = $sql->fetch_assoc()){
            foreach($row as $a){
                $rel[] = $a;
            }
        }

        if(count($rel) == 0){
            echo "<p style='color: white;'>Dados inválidos!</p>";
        } else {
            $id_usuario = $rel[0];
            $usuario_db = $rel[1];
            $senha_db = $rel[2];  
            $cargo_db = $rel[3];

            if(($p_user == $usuario_db && $p_senha == $senha_db)) {
                $_SESSION['idUser'] = $id_usuario;
                $_SESSION['usuario'] = $usuario_db;
                $_SESSION['senha'] = $senha_db;
                $_SESSION['cargo'] = $cargo_db;
                $_SESSION['logged'] = True;
            } else {
                echo "<p style='color: white;'>Usuário ou senha são <b>diferentes</b> ou não <b>existem</b>.</p>";
            }
        }

    }

?>