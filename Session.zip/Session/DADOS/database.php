
<?php
    $servername = "localhost";
    $database = "sistema";
    $username = "root";
    $password = "usbw";

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        echo "Conexão Falhou: " . mysqli_connect_error();
    }
?>