
<?php 

    include_once 'DADOS/dados_login.php';

?>

<!DOCTYPE html>
<html>
<head>
    <title>Session</title>
    <meta charset="UTF-8">
</head>
<body>
    <div class="container">
        <?php
            if(!$_SESSION['logged']) {
                include_once 'FORM/form_login.php';
            } else {
                include_once 'dashboard.php';
            }
        ?>
    </div>    
</body>
</html>