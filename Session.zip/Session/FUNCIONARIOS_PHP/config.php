
<?php

    include_once '../DADOS/dados_login.php';
    require_once('../DADOS/database.php');


    $sql = $conn->prepare("TRUNCATE TABLE pessoa");
    $sql->execute();

    $sql2 = $conn->prepare("INSERT INTO pessoa(nome,senha,valor,cargo) VALUES('Gustavo', 2020, 0, 'chefe')");
    $sql2->execute();

    echo "<script>alert('Edição realizada com sucesso! Atualize a página.')</script>";


?>