
<?php

    if(isset($_REQUEST['addNome']) && isset($_REQUEST['addCargo']) && isset($_REQUEST['addSenha'])) {

        require_once('../DADOS/database.php');

        $t = $conn->query("SELECT nome FROM pessoa");
        $conta = 0;
    
        while($ids = $t->fetch_assoc()){
            foreach($ids as $y){
                $_SESSION['nomeFunc'][$conta]["nome"] = $y;
            } $conta++;
        }
    
        if(array_search($_REQUEST['addNome'], array_column($_SESSION['nomeFunc'], 'nome')) == false) {

            $sql = $conn->prepare("INSERT INTO pessoa(nome,senha,valor,cargo) VALUES('{$_REQUEST["addNome"]}', '{$_REQUEST["addSenha"]}', 0,'{$_REQUEST["addCargo"]}')");
            $sql->execute();
            
            echo "<script>alert('Upload realizado com sucesso! Atualize a página.')</script>";

        } else {
            echo "<script>alert('Nome já existente no banco!')</script>";
        }

    } else {
        echo "<script>alert('Algum campo sem preenchimento!')</script>";
    }


?>