
<?php

include_once '../DADOS/dados_login.php';

if(isset($_REQUEST['ExcluirID2'])) {

    require_once('../DADOS/database.php');

    $s = $conn->query("SELECT MAX(id) FROM pessoa");

    while($r = $s->fetch_assoc()){
        foreach($r as $o){
            $_SESSION['idMaximo2'] = $o;
        }
    }

    $t = $conn->query("SELECT id FROM pessoa");
    $conta = 0;

    while($ids = $t->fetch_assoc()){
        foreach($ids as $y){
            $_SESSION['valID2'][$conta]["id"] = $y;
        } $conta++;
    }

    if($_REQUEST['ExcluirID2'] < $_SESSION['idMaximo2']){

        if(array_search($_REQUEST['ExcluirID2'], array_column($_SESSION['valID2'], 'id')) !== false) {

            $sql = $conn->prepare("DELETE FROM pessoa WHERE id = {$_REQUEST['ExcluirID2']}");
            $sql->execute();
        
            echo "<script>alert('Exclusão realizada com sucesso! Atualize a página.')</script>";
            
        } else {

            echo "<script>alert('ID não encontrado! Tente novamente.')</script>";

        }
 
    } else {

        echo "<script>alert('ID não encontrado! Tente novamente.')</script>";

        return false;

    }

} else {

    echo "<script>alert('Campo ID sem preenchimento!')</script>";

}


?>