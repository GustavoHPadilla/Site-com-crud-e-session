
<?php

    include_once '../DADOS/dados_login.php';

    if(isset($_REQUEST['editarNome']) && isset($_REQUEST['editarSenha']) && isset($_REQUEST['editarCargo'])) {

        require_once('../DADOS/database.php');

        $sql = $conn->prepare("UPDATE pessoa SET 
        nome = '{$_REQUEST["editarNome"]}', 
        senha = '{$_REQUEST["editarSenha"]}', 
        cargo = '{$_REQUEST["editarCargo"]}'
        WHERE id = {$_SESSION['idFuncao2']}");

        $sql->execute();
        
        echo "<script>alert('Edição realizada com sucesso! Atualize a página.')</script>";

    } else {
        echo "<script>alert('Algum campo sem preenchimento!')</script>";
    }


?>