

<?php

    include_once 'DADOS/dados_login.php';
    
    $logged = $_SESSION['logged'] ?? NULL;
    if(!$logged) die('Erro! Página não encontrada');

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/style-ord_compra.css">
</head>
<body>
    <section>
        <?php

        include_once 'ALERTAS/alerta.php';

        ?>
        <table id="table">
            <tr>
                <td class="td_titulo0">ID</td>
                <td class="td_titulo1">Descrição</td>
                <td class="td_titulo2">Valor</td>
                <td class="td_titulo3">Quantidade</td>
                <td class="td_titulo4">Valor Total</td>
                <td class="td_titulo5"><button style='padding: 6px;'></button></td>
            </tr>
            <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
            <?php

                require_once('DADOS/database.php');

                if(isset($_REQUEST['id_produto'])){

                    if($_SESSION['contador'] == null){
                        $_SESSION['contador'] = 0;
                    }

                    $_SESSION['id_produto'] = $_REQUEST['id_produto'];
                    $_SESSION['qtd_produto'] = $_REQUEST['qtd_produto'];
                    $qtd = $_SESSION['qtd_produto'];

                    $sql1 = $conn->query("SELECT id,descricao,valorUnitario FROM estoque WHERE id = '{$_SESSION['id_produto']}'");

                    while($row = $sql1->fetch_array()){

                        $valorTotal = $row[2] * $_SESSION['qtd_produto'];
                        
                        $_SESSION['valores'][$_SESSION['contador']]["id"] = $row[0];
                        $_SESSION['valores'][$_SESSION['contador']]["desc"] = $row[1];
                        $_SESSION['valores'][$_SESSION['contador']]["valor"] = $row[2];
                        $_SESSION['valores'][$_SESSION['contador']]["qtd"] = $qtd;
                        $_SESSION['valores'][$_SESSION['contador']]["vTotal"] = $valorTotal;

                    }

                    if(array_key_exists($_SESSION['contador'], $_SESSION['valores'])){

                        $_SESSION['contador'] = $_SESSION['contador'] + 1;

                        for($i = 0; $i < $_SESSION['contador']; $i++){ ?>
                    
                            <tr>
                                <td><?php echo $_SESSION['valores'][$i]["id"]; ?></td>
                                <td><?php echo $_SESSION['valores'][$i]["desc"]; ?></td>
                                <td><?php echo $_SESSION['valores'][$i]["valor"]; ?></td>
                                <td><?php echo $_SESSION['valores'][$i]["qtd"]; ?></td>
                                <td><?php echo $_SESSION['valores'][$i]["vTotal"]; ?></td>
                            </tr>
    
                        <?php }

                    }
                    else {

                        echo "<script>alert('Produto Inexistente!')</script>";
                     
                        for($i = 0; $i < $_SESSION['contador']; $i++){ ?>
                    
                            <tr>
                                <td><?php echo $_SESSION['valores'][$i]["id"]; ?></td>
                                <td><?php echo $_SESSION['valores'][$i]["desc"]; ?></td>
                                <td><?php echo $_SESSION['valores'][$i]["valor"]; ?></td>
                                <td><?php echo $_SESSION['valores'][$i]["qtd"]; ?></td>
                                <td><?php echo $_SESSION['valores'][$i]["vTotal"]; ?></td>
                            </tr>
    
                        <?php }
                        
                    }

                } 
                        
            ?>
        </table>
    </section>
    <section>
        <form action="" method="POST">
            <input type="number" placeholder="ID" name="id_produto" required/>
            <input type="number" placeholder="QUANTIDADE" name="qtd_produto" required/>

            <input type="submit" value="Adicionar" name="add_produto" class="add_produto"/>
            <a href="?finalizar=1" class="fim">Finalizar</a>
        </form>
    </section>
</body>
</html>