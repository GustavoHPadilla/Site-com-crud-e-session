
<?php

include_once 'DADOS/dados_login.php';

$logged = $_SESSION['logged'] ?? NULL;
if(!$logged) die('Erro! Página não encontrada');

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/style-func3.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <script src="JS/app.js" defer></script>
    </head>
<body>
<section>
<table id="table">
    <tr>
        <td class="td_titulo0">ID</td>
        <td class="td_titulo1">Nome</td>
        <td class="td_titulo2">Senha</td>
        <td class="td_titulo3">Cargo</td>
        <td class="td_titulo4">Info. de cadastro</td>
    </tr>
    <?php

        require_once('DADOS/database.php');

        $sql2 = $conn->query("SELECT * FROM pessoa");

        while($row = $sql2->fetch_array()){

            ?>
            
                <tr>
                    <td><?php echo $row[0]; ?></td>
                    <td><?php echo $row[1]; ?></td>
                    <td><?php echo $row[2]; ?></td>
                    <td><?php echo $row[5]; ?></td>
                    <td><?php echo $row[3]; ?></td>
                </tr>

            <?php 

        }

    ?>
</table>
</section>
<div class="modalAdicionar" id="modalAdicionar">
    <div class="cima-add">
        <hr style="visibility: hidden;">
        <h3>Adicionar funcionário</h3>
        <hr>
    </div>
    <form action="FUNCIONARIOS_PHP/add.php" method="POST">
        <input type="text" placeholder="Nome" name="addNome" id="form1" autocomplete="off" required/>
        
        <p class="p1"><input type="radio" name="addCargo" id="form2" value="func" checked required/>ㅤFuncionário</p>
        <p class="p2"><input type="radio" name="addCargo" id="form2" value="chefe" required/>ㅤChefe</p>
        
        <input type="number" placeholder="Senha" name="addSenha" autocomplete="off" id="form3" required/>

        <div class="opcoes-add">
            <div class="limpar">
                <input type="button" value="Limpar" onclick="limparInput(1)" name="limpar_produto" class="limpar_produto">
            </div>
            <div class="botoes">
                <input type="button" value="Cancelar" onclick="fecharModal(1)" name="cancel_produto" class="cancel_produto"/>
                <input type="submit" value="Salvar" name="add_produto" class="add_produto"/>
            </div>
        </div>
    </form>
</div>
<div></div>
<div class="modalEditar" id="modalEditar">
    <div class="cima-add">
        <hr style="visibility: hidden;">
        <h3>Editar funcionário</h3>
        <hr>
    </div>
    <form action="FUNCIONARIOS_PHP/edit.php" method="POST" id="formEditar">
        <input type="text" placeholder="Nome" name="editarNome" id="form4" class="inpEdit form4" required/>
        <input type="text" placeholder="Senha" name="editarSenha" id="form5"class="inpEdit form5" required/>

        <p class="p3"><input type="radio" name="editarCargo" id="form6" value="func" checked required/>ㅤFuncionário</p>
        <p class="p4"><input type="radio" name="editarCargo" id="form0" value="chefe" required/>ㅤChefe</p>
        
        <div class="opcoes-add">
            <div class="limpar">
                <input type="button" value="Limpar" onclick="limparInput(2)" name="limpar_produto" class="limpar_produto">
            </div>
            <div class="botoes">
                <input type="button" value="Cancelar" onclick="fecharModal(2), apagarBtn(1)" name="cancel_produto" class="cancel_produto"/>
                <input type="submit" value="Salvar" onclick="apagarBtn(1)" name="editar_produto" class="editar_produto"/>
            </div>
        </div>
    </form>
</div>
<div class="modalExcluir" id="modalExcluir">
    <div class="cima-add">
        <hr style="visibility: hidden;">
        <h3>Excluir funcionário</h3>
        <hr>
    </div>
    <form action="FUNCIONARIOS_PHP/excluir.php" method="POST" id="formExcluir">
        <input type="number" placeholder="ID" name="ExcluirID2" id="form7" class="inpExcluir" required/>
    
        <div class="opcoes-add">
            <div class="limpar">
                <input type="button" value="Limpar" onclick="limparInput(3)" name="limpar_produto" class="limpar_produto">
            </div>
            <div class="botoes">
                <input type="button" value="Cancelar" onclick="fecharModal(3)" name="cancel_produto" class="cancel_produto"/>
                <input type="submit" value="Salvar" name="Excluir_produto" class="Excluir_produto"/>
            </div>
        </div>
    </form>
</div>
<div class="modalConfig" id="modalConfig">
    <div class="cima-add">
        <hr style="visibility: hidden;">
        <h3>Configurações</h3>
        <hr>
    </div>
    <form action="" method="POST" id="formConfig">
        <a href="FUNCIONARIOS_PHP/config.php" id="form7" class="inpConfig">Truncate Table</a>

        <div class="opcoes-add">
            <div class="botoes">
                <input type="button" value="Fechar" onclick="fecharModal(3)" name="Config_produto" class="Config_produto"/>
            </div>
        </div>
    </form>
</div>
<section class="sec"> 
    <div class="searchID">
        <form action="" method="POST" id="formIDEditar">
            <input type="number" placeholder="ID" name="IDeditar2" id="formId" class="inpEditSearch" required/>
            <input type="submit" class="fa-solid fa-magnifying-glass" value="🔍">
        </form>
    </div>
    <div class="dv">
        <button onclick="abrirModal(1)" class="btnAdd">Adicionar funcionário</button>
        <?php

            if(isset($_REQUEST['IDeditar2'])){

                $_SESSION['idFuncao2'] = $_REQUEST['IDeditar2'];
                
        
                $sql = $conn->query("SELECT id,nome,senha,cargo FROM pessoa WHERE id = {$_SESSION['idFuncao2']}");

                while($row = $sql->fetch_array()){
                    $_SESSION['editarId2'] = $row[0];
                    $_SESSION['editarNome'] = $row[1];
                    $_SESSION['editarSenha'] = $row[2];
                    $_SESSION['editarCargo'] = $row[3];
                }

                if($_SESSION['editarId2'] != $_SESSION['idFuncao2']){
                    echo "<script>alert('ID informado não existe nos registros.')</script>";
                }
                else {
                    echo "<button onclick='abrirModal(2)' class='btnEdit'>Editar funcionário</button>";
                    echo "<script>
                        document.querySelector('.form4').value = '{$_SESSION['editarNome']}'
                        document.querySelector('.form5').value = '{$_SESSION['editarSenha']}'
                        </script>";
                }

            }
                
        ?>
        <div class="conj">
            <button onclick="abrirModal(3)" class="btnExcluir">Remover funcionário</button>
            <button class="btnConfig"><i onclick="abrirModal(9)" class="fa-solid fa-gear"></i></button>
        </div>
    </div>
</section>
</body>
</html>