

<?php

    include_once 'DADOS/dados_login.php';

    $logged = $_SESSION['logged'] ?? NULL;
    if(!$logged) die('Erro! Página não encontrada');

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style-estoque4.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="JS/app.js" defer></script>
</head>
<body>
<section>
    <table id="table">
        <tr>
            <td class="td_titulo0">ID</td>
            <td class="td_titulo1">Descrição</td>
            <td class="td_titulo2">Valor</td>
            <td class="td_titulo3">Unidades</td>
        </tr>
        <?php

            require_once('DADOS/database.php');

            $sql2 = $conn->query("SELECT * FROM estoque");

            while($row = $sql2->fetch_array()){

                ?>
                
                    <tr>
                        <td><?php echo $row[0]; ?></td>
                        <td><?php echo $row[1]; ?></td>
                        <td><?php echo $row[2]; ?></td>
                        <td><?php echo $row[3]; ?></td>
                    </tr>

                <?php 

            }

        ?>
    </table>
</section>
<div class="modalAdicionar" id="modalAdicionar">
    <div class="cima-add">
        <hr style="visibility: hidden;">
        <h3>Adicionar produto</h3>
        <hr>
    </div>
    <form action="ESTOQUE_PHP/add.php" method="POST">
        <input type="text" placeholder="Descrição" name="adicionarDescricao" id="form1" required/>
        <input type="number" placeholder="Preço" name="adicionarValor" id="form2" required/>
        <input type="number" placeholder="Unidades" name="adicionarUnidades" id="form3" required/>

        <div class="opcoes-add">
            <div class="limpar">
                <input type="button" value="Limpar" onclick="limparInput(1)" name="limpar_produto" class="limpar_produto">
            </div>
            <div class="botoes">
                <input type="button" value="Cancelar" onclick="fecharModal(1)" name="cancel_produto" class="cancel_produto"/>
                <input type="submit" value="Salvar" name="add_produto" class="add_produto"/>
            </div>
        </div>
    </form>
</div>
<div></div>
<div class="modalEditar" id="modalEditar">
    <div class="cima-add">
        <hr style="visibility: hidden;">
        <h3>Editar produto</h3>
        <hr>
    </div>
    <form action="ESTOQUE_PHP/edit.php" method="POST" id="formEditar">
        <input type="text" placeholder="Descrição" name="editarDescricao" id="form4" class="inpEdit" required/>
        <input type="text" placeholder="Preço" name="editarValor" id="form5"class="inpEdit" required/>
        <input type="number" placeholder="Unidades" name="editarUnidades" id="form6" class="inpEdit" required/>
    
        <div class="opcoes-add">
            <div class="limpar">
                <input type="button" value="Limpar" onclick="limparInput(2)" name="limpar_produto" class="limpar_produto">
            </div>
            <div class="botoes">
                <input type="button" value="Cancelar" onclick="fecharModal(2), apagarBtn(1)" name="cancel_produto" class="cancel_produto"/>
                <input type="submit" value="Salvar" onclick="apagarBtn(1)" name="editar_produto" class="editar_produto"/>
            </div>
        </div>
    </form>
</div>
<div class="modalExcluir" id="modalExcluir">
    <div class="cima-add">
        <hr style="visibility: hidden;">
        <h3>Excluir produto</h3>
        <hr>
    </div>
    <form action="ESTOQUE_PHP/excluir.php" method="POST" id="formExcluir">
        <input type="number" placeholder="ID" name="ExcluirID" id="form7" class="inpExcluir" required/>
    
        <div class="opcoes-add">
            <div class="limpar">
                <input type="button" value="Limpar" onclick="limparInput(3)" name="limpar_produto" class="limpar_produto">
            </div>
            <div class="botoes">
                <input type="button" value="Cancelar" onclick="fecharModal(3)" name="cancel_produto" class="cancel_produto"/>
                <input type="submit" value="Salvar" name="Excluir_produto" class="Excluir_produto"/>
            </div>
        </div>
    </form>
</div>
<div class="modalConfig" id="modalConfig">
    <div class="cima-add">
        <hr style="visibility: hidden;">
        <h3>Configurações</h3>
        <hr>
    </div>
    <form action="" method="POST" id="formConfig">
        <a href="ESTOQUE_PHP/config.php" id="form7" class="inpConfig">Truncate Table</a>

        <div class="opcoes-add">
            <div class="botoes">
                <input type="button" value="Fechar" onclick="fecharModal(3)" name="Config_produto" class="Config_produto"/>
            </div>
        </div>
    </form>
</div>
<section class="sec"> 
    <div class="searchID">
        <form action="" method="POST" id="formIDEditar">
            <input type="number" placeholder="ID" name="IDeditar" id="formId" class="inpEditSearch" required/>
            <input type="submit" class="fa-solid fa-magnifying-glass" value="🔍">
        </form>
    </div>
    <div class="dv">
        <button onclick="abrirModal(1)" class="btnAdd">Adicionar Produto</button>
        <?php

            if(isset($_REQUEST['IDeditar'])){

                $_SESSION['idFuncao'] = $_REQUEST['IDeditar'];
                
                
                $sql = $conn->query("SELECT * FROM estoque WHERE id = {$_SESSION['idFuncao']}");

                while($row = $sql->fetch_array()){
                    $_SESSION['editarId'] = $row[0];
                    $_SESSION['editarDesc'] = $row[1];
                    $_SESSION['editarValor'] = $row[2];
                    $_SESSION['editarUnd'] = $row[3];
                }

                if($_SESSION['editarId'] != $_SESSION['idFuncao']){
                    echo "<script>alert('ID informado não existe nos registros.')</script>";
                }
                else {
                    echo "<button onclick='abrirModal(2)' class='btnEdit'>Editar Produto</button>";
                    echo "<script>
                        document.getElementById('form4').value = '{$_SESSION['editarDesc']}'
                        document.getElementById('form5').value = '{$_SESSION['editarValor']}'
                        document.getElementById('form6').value = '{$_SESSION['editarUnd']}'
                        </script>";
                }

            }
                
        ?>
        <div class="conj">
            <button onclick="abrirModal(3)" class="btnExcluir">Excluir Produto</button>
            <button class="btnConfig"><i onclick="abrirModal(9)" class="fa-solid fa-gear"></i></button>
        </div>
    </div>
</section>
</body>
</html>