


function limparInput(n) {

    var form = n;
    
    if(form == 1){
        document.getElementById("form1").value = ""
        document.getElementById("form2").value = ""
        document.getElementById("form3").value = ""
    }

    if(form == 2){
        document.getElementById("form4").value = ""
        document.getElementById("form5").value = ""
        document.getElementById("form6").value = ""
    }

    if(form == 3){
        document.getElementById("form7").value = ""
    }

}

function abrirModal(n) {

    var form = n;

    document.getElementById("form4").style.visibility = "visible"
    document.getElementById("form5").style.visibility = "visible"
    document.getElementById("form6").style.visibility = "visible"

    if(form == 1){
        document.querySelector('#modalAdicionar').style.animation = "abrirModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalAdicionar').style.display = "flex"
        }, 100)
        document.querySelector('#modalEditar').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalEditar').style.display = "none"
        }, 100)
        document.querySelector('#modalConfig').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalConfig').style.display = "none"
        }, 100)
        document.querySelector('#modalExcluir').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalExcluir').style.display = "none"
        }, 100)
    }

    if(form == 2){
        document.querySelector('#modalEditar').style.animation = "abrirModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalEditar').style.display = "flex"
        }, 100)
        document.querySelector('#modalAdicionar').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalAdicionar').style.display = "none"
        }, 100)
        document.querySelector('#modalConfig').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalConfig').style.display = "none"
        }, 100)
        document.querySelector('#modalExcluir').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalExcluir').style.display = "none"
        }, 100)
    }

    if(form == 3){
        document.querySelector('#modalEditar').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalEditar').style.display = "none"
        }, 100)
        document.querySelector('#modalAdicionar').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalAdicionar').style.display = "none"
        }, 100)
        document.querySelector('#modalConfig').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalConfig').style.display = "none"
        }, 100)
        document.querySelector('#modalExcluir').style.animation = "abrirModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalExcluir').style.display = "flex"
        }, 100)
    }

    if(form == 9){
        document.querySelector('#modalEditar').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalEditar').style.display = "none"
        }, 100)
        document.querySelector('#modalAdicionar').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalAdicionar').style.display = "none"
        }, 100)
        document.querySelector('#modalExcluir').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalExcluir').style.display = "none"
        }, 100)
        document.querySelector('#modalConfig').style.animation = "abrirModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalConfig').style.display = "flex"
        }, 100)
    }

}

function apagarBtn(n) {
    
    na = n;

    if(na == 1){
        document.querySelector('.btnEdit').style.display = "none";
    }

}

function fecharModal(n) {

    var form = n;

    if(form == 1){
        document.querySelector('#modalAdicionar').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalAdicionar').style.display = "none"
        }, 100)
    }

    if(form == 2){
        document.querySelector('#modalEditar').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalEditar').style.display = "none"
        }, 100)
    }

    if(form == 3){
        document.querySelector('#modalExcluir').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalExcluir').style.display = "none"
        }, 100)
    }

    if(form == 3){
        document.querySelector('#modalConfig').style.animation = "fecharModal .3s ease forwards"
        setTimeout(() => {
            document.querySelector('#modalConfig').style.display = "none"
        }, 100)
    }

}