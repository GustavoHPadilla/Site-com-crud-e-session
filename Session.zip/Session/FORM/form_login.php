<link rel="stylesheet" href="CSS/style-form_login1.css">
<form action="" method="post">
    <div>
        <label for="user">USUARIO</label>
        <input type="text" name="user" class="user" required>
    </div>
    <div>
        <label for="pass">SENHA</label>
        <input type="password" name="pass" class="pass" required>
    </div>
    <input type="submit" value="Entrar no sistema">
</form>