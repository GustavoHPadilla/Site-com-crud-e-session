
<?php

    include_once 'DADOS/dados_login.php';

    $logged = $_SESSION['logged'] ?? NULL;
    if(!$logged) die('Erro! Página não encontrada');

?>

<?php

    require_once 'DADOS/database.php';

    $sql1 = $conn->query("SELECT valor FROM pessoa WHERE nome = '{$_SESSION['usuario']}'");

    while($row = $sql1->fetch_assoc()){
        foreach($row as $a){
            $v = $a;
        }
    }

    $_SESSION['val'] = $v ?? 0;

?>

<?php if($_SESSION['cargo'] == "chefe") { ?>

    <!DOCTYPE html>
    <html> 
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/style-dash.css">
    </head>
    <body>
        <header>
            <p>Olá <b><?php echo $_SESSION['usuario']; ?></b>, bem-vindo de volta!</p>
            <h2>Vendas total: <b><?php echo $_SESSION['val']; ?></b></h2>
        </header>
        <section>
            <div>
                <a href="?opc=1" class="link">Ord. de compra</a>
                <a href="?opc=2" class="link">Estoque</a>
                <a href="?opc=3" class="link">Funcionários</a>
                <a href="?logout=1" class="link sair">Sair</a>
            </div>
            <?php

                $_SESSION['contador'] = 0;
                $_SESSION['valores'] = array();
                
                if(isset($_REQUEST['opc']) && $_REQUEST['opc'] == 1){
                    echo "";
                    echo '<iframe src="ordem_de_compra.php" frameborder="0" class="pagina_1" id="link-01"></iframe>';
                }
                else if(isset($_REQUEST['opc']) && $_REQUEST['opc'] == 2){
                    echo "";
                    echo '<iframe src="estoque.php" frameborder="0" class="pagina_2" id="link-02"></iframe>';
                }
                else if(isset($_REQUEST['opc']) && $_REQUEST['opc'] == 3){
                    echo "";
                    echo '<iframe src="funcionarios.php" frameborder="0" class="pagina_3" id="link-03"></iframe>';
                }
            ?>
        </section>
    </body> 
    </html>

<?php } ?>


<?php if($_SESSION['cargo'] == "func") { ?>

<!DOCTYPE html>
<html> 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style-dash.css">
</head>
<body>
    <header>
        <p>Olá <b><?php echo $_SESSION['usuario']; ?></b>, bem-vindo de volta!</p>
        <h2>Vendas total: <b><?php echo $_SESSION['val']; ?></b></h2>
    </header>
    <section>
        <div>
            <a href="" class="link">Ord. de compra</a>
            <a href="?logout=1" class="link sair">Sair</a>
        </div>
        <iframe src="ordem_de_compra.php" frameborder="0" class="pagina_1" id="link-01"></iframe>
    </section>
</body> 
</html>

<?php } ?>