
<?php

include_once '../DADOS/dados_login.php';

if(isset($_REQUEST['ExcluirID'])) {

    require_once('../DADOS/database.php');

    $s = $conn->query("SELECT MAX(id) FROM estoque");

    while($r = $s->fetch_assoc()){
        foreach($r as $o){
            $_SESSION['idMaximo'] = $o;
        }
    }

    $t = $conn->query("SELECT id FROM estoque");

    $conta = 0;

    while($ids = $t->fetch_assoc()){

        foreach($ids as $y){
            $_SESSION['valID'][$conta]["id"] = $y;
        }

        $conta++;

    }

    if($_REQUEST['ExcluirID'] < $_SESSION['idMaximo']){

        if(array_search($_REQUEST['ExcluirID'], array_column($_SESSION['valID'], 'id')) !== false) {

            $sql = $conn->prepare("DELETE FROM estoque WHERE id = {$_REQUEST['ExcluirID']}");
            $sql->execute();
        
            echo "<script>alert('Exclusão realizada com sucesso! Atualize a página.')</script>";
            
        } else {

            echo "<script>alert('ID não encontrado! Tente novamente.')</script>";

        }
 
    } else {

        echo "<script>alert('ID não encontrado! Tente novamente.')</script>";

        return false;

    }

} else {

    echo "<script>alert('Campo ID sem preenchimento!')</script>";

}


?>