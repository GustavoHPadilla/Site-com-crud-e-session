
<?php

    include_once '../DADOS/dados_login.php';
    require_once('../DADOS/database.php');


    $sql = $conn->prepare("TRUNCATE TABLE estoque");
    $sql->execute();

    echo "<script>alert('Edição realizada com sucesso! Atualize a página.')</script>";


?>