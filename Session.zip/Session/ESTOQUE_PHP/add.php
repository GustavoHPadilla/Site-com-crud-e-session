
<?php

    if(isset($_REQUEST['adicionarDescricao']) && isset($_REQUEST['adicionarValor']) && isset($_REQUEST['adicionarUnidades'])) {

        require_once('../DADOS/database.php');

        $sql = $conn->prepare("INSERT INTO estoque(descricao,valorUnitario,unidades) VALUES(?, ?, ?)");
        $sql->bind_param("sdi", $_REQUEST['adicionarDescricao'], $_REQUEST['adicionarValor'], $_REQUEST['adicionarUnidades']);
        $sql->execute();
        
        echo "<script>alert('Upload realizado com sucesso! Atualize a página.')</script>";

    } else {
        echo "<script>alert('Algum campo sem preenchimento!')</script>";
    }


?>