
<?php

    include_once '../DADOS/dados_login.php';

    if(isset($_REQUEST['editarDescricao']) && isset($_REQUEST['editarValor']) && isset($_REQUEST['editarUnidades'])) {

        require_once('../DADOS/database.php');

        $sql = $conn->prepare("UPDATE estoque SET 
        descricao = '{$_REQUEST['editarDescricao']}', 
        valorUnitario = {$_REQUEST['editarValor']}, 
        unidades = {$_REQUEST['editarUnidades']}
        WHERE id = {$_SESSION['idFuncao']}");

        $sql->execute();
        
        echo "<script>alert('Edição realizada com sucesso! Atualize a página.')</script>";

    } else {
        echo "<script>alert('Algum campo sem preenchimento!')</script>";
    }


?>